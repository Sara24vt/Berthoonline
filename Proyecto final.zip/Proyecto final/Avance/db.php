<?php
$host = 'localhost';
$dbname = 'login_db';
$username = 'SARA24\SQLEXPRESS'; // Reemplaza con tu usuario de base de datos

try {
    $conn = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8", $username);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    echo "Error de conexión: " . $e->getMessage();
}
?>
